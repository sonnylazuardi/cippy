app.directive('sharePanel', function() {
  return {
    restrict: 'A',
    controller: 'SharePanelController',
    templateUrl: 'partials/editor/share-panel.html',
    link: function(scope, element, attr){
      
    }
  }
});