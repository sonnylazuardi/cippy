app.constant('CouchURL', 'http://localhost:5984/');
app.constant('_ArrangementDB', 'cippy_arrangements');
app.constant('_ChatDB', 'cippy_chats');
app.constant('_UserDB', 'cippy_users');
app.constant('_SharedDB', 'cippy_shared');
app.constant('_ProjectDB', 'cippy_projects');
app.constant('FBClientId', '468348829982756');