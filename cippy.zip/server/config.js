// DEVELOPMENT
module.exports = {
  type: 'development',
  appPort: 8080,
  aws: {
    s3Bucket: 'sonnylazuardi',
    accessKey: 'AKIAIC6C2LITVA33J2GQ',
    secret: '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'
  },
  TOKEN_SECRET: 'A hard to guess token',
  FACEBOOK_SECRET: 'ab201ff90f617a8c7b40a553dfef42f7',
};