app.service('EditorConfig', function(){
  return {
    pixelsPerSecond: 50,
    track_settings_offset: 190
  }
});