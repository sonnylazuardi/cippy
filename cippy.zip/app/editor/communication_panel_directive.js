app.directive('communicationPanel', function() {
  return {
    restrict: 'A',
    controller: 'CommunicationPanelController',
    templateUrl: 'partials/editor/communication-panel.html',
    link: function(scope, element, attr){
      
    }
  }
});