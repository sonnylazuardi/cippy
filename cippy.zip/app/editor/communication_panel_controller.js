app.controller('CommunicationPanelController', function($rootScope, $scope, Arrangement, Chat, $http, $auth, Account){
    
  $scope.hideCommunicationPanel = function(){
    $rootScope.showCommunicationPanel = false;
  };

  Account.getProfile()
    .success(function(data) {
      $scope.user = data;
    });

  $scope.message = '';
  $scope.chats = [];
  Chat.bind('mantapkali', $scope, 'chats');

  $scope.send = function() {
    var newMessage = {
      _id: new Date().toISOString(),
      arrangement_id: 'mantapkali',
      content: $scope.message,
      user: $scope.user,
      time: new Date(),
    };
    Chat.add(newMessage);
    $scope.message = '';

  }

});