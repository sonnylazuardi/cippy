app.directive('editorTracks', function() {
  return {
    restrict: 'E',
    templateUrl: 'partials/editor/tracks.html'
  }
});