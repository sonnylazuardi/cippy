app.controller('SynthesizerPieceEditController', ['$rootScope', '$scope', 'utils', 'Arrangement', 'Synthesizer',
  function($rootScope, $scope, utils, Arrangement, Synthesizer){


}]);